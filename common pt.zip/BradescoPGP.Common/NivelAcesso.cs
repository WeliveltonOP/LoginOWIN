﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BradescoPGP.Common
{
    public enum NivelAcesso
    {
        Master = 1, 
        Especialista = 2,
        Gestor
    }
}
